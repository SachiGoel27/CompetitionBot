import numpy as np
import time
import os
import json
import random
from game.enums import Cell, Noise, MoveType, Direction, CARPET_POINTS_TABLE
from game.move import Move

NOISE_PROBS = {
    Cell.BLOCKED: (0.5, 0.3, 0.2),
    Cell.SPACE: (0.7, 0.15, 0.15),
    Cell.PRIMED: (0.1, 0.8, 0.1),
    Cell.CARPET: (0.1, 0.1, 0.8),
}

# ==========================================
# THE TRACKER (HMM)
# ==========================================
class RatBelief:
    def __init__(self, T_matrix):
        self.T = np.array(T_matrix)
        
        # Cache the stationary distribution once to save massive compute on resets
        initial_state = np.zeros(64)
        initial_state[0] = 1.0
        T_1000 = np.linalg.matrix_power(self.T, 1000)
        self.stationary_belief = initial_state @ T_1000
        
        self.belief = np.zeros(64)
        self.reset_and_headstart()

    def reset_and_headstart(self):
        # Instantly copy the cached distribution instead of recalculating
        self.belief = self.stationary_belief.copy()

    def predict(self):
        self.belief = self.belief @ self.T

    def update(self, noise, reported_distance, my_pos, board):
        likelihood = np.zeros(64)
        my_x, my_y = my_pos
        
        for i in range(64):
            x, y = i % 8, i // 8
            cell_type = board.get_cell((x, y))
            p_noise = NOISE_PROBS[cell_type][noise.value]
            
            actual_dist = abs(my_x - x) + abs(my_y - y)
            p_dist = 0.0
            
            if reported_distance == 0:
                if actual_dist == 0: p_dist = 0.82
                elif actual_dist == 1: p_dist = 0.12
            else:
                if actual_dist == reported_distance: p_dist = 0.70
                elif actual_dist == reported_distance + 1: p_dist = 0.12
                elif actual_dist == reported_distance - 1: p_dist = 0.12
                elif actual_dist == reported_distance - 2: p_dist = 0.06
            
            likelihood[i] = p_noise * p_dist
            
        self.belief *= likelihood
        self.normalize()

    def normalize(self):
        total_prob = np.sum(self.belief)
        if total_prob > 0:
            self.belief /= total_prob
        else:
            self.belief = np.ones(64) / 64.0

    def get_best_guess(self):
        best_idx = np.argmax(self.belief)
        return (best_idx % 8, best_idx // 8), self.belief[best_idx]


# ==========================================
# THE MAIN AGENT
# ==========================================
class PlayerAgent:
    def __init__(self, board, transition_matrix, time_left_func):
        self.hmm = RatBelief(transition_matrix)
        
        # Expanded time buffer to prevent accidental timeouts
        self.TIME_BUFFER = 0.8 
        self.tt = {} # Transposition Table
        
        self.weights = {
            "rat_confidence_threshold": 0.0 
        }
        
        if 'AGENT_WEIGHTS' in os.environ:
            try:
                self.weights.update(json.loads(os.environ['AGENT_WEIGHTS']))
            except Exception as e:
                pass

    def check_rat_resets(self, board):
        # 1. Did I guess last turn?
        my_guess, my_correct = board.player_search
        if my_guess is not None:
            if my_correct:
                self.hmm.reset_and_headstart()
                return # Rat caught, new rat spawned. Ignore opponent's action.
            else:
                # THE FIX: Zero out the square we just checked!
                my_idx = my_guess[1] * 8 + my_guess[0]
                self.hmm.belief[my_idx] = 0.0
                self.hmm.normalize()
                
        # 2. Did the opponent guess last turn?
        op_guess, op_correct = board.opponent_search
        if op_guess is not None:
            if op_correct:
                self.hmm.reset_and_headstart()
            else:
                op_idx = op_guess[1] * 8 + op_guess[0]
                self.hmm.belief[op_idx] = 0.0
                self.hmm.normalize()

    def _hash_board(self, board, is_maximizing):
        """Creates a fast, unique tuple representing the current board state."""
        return (
            board.player_worker.get_location(),
            board.opponent_worker.get_location(),
            board.player_worker.get_points(),
            board.opponent_worker.get_points(),
            tuple(board.get_cell((x, y)) for x in range(8) for y in range(8)),
            is_maximizing
        )

    def heuristic(self, board):
        score = board.player_worker.get_points() - board.opponent_worker.get_points()
        
        my_x, my_y = board.player_worker.get_location()
        en_x, en_y = board.opponent_worker.get_location()
        
        # HELPER: Calculates distance strictly to VALID entry squares
        def dist_to_roll_endpoints(worker_x, worker_y, line_coords, is_horizontal):
            if not line_coords: return float('inf')
            
            start_x, start_y = line_coords[0]
            end_x, end_y = line_coords[-1]
            
            dist1 = float('inf')
            dist2 = float('inf')
            
            if is_horizontal:
                if start_x > 0 and board.get_cell((start_x - 1, start_y)) != Cell.BLOCKED:
                    dist1 = abs(worker_x - (start_x - 1)) + abs(worker_y - start_y)
                if end_x < 7 and board.get_cell((end_x + 1, end_y)) != Cell.BLOCKED:
                    dist2 = abs(worker_x - (end_x + 1)) + abs(worker_y - end_y)
            else:
                if start_y > 0 and board.get_cell((start_x, start_y - 1)) != Cell.BLOCKED:
                    dist1 = abs(worker_x - start_x) + abs(worker_y - (start_y - 1))
                if end_y < 7 and board.get_cell((start_x, end_y + 1)) != Cell.BLOCKED:
                    dist2 = abs(worker_x - start_x) + abs(worker_y - (end_y + 1))
            
            return min(dist1, dist2)

        # HELPER: Evaluates the value and gravity of a specific line
        def evaluate_line(line_coords, is_horizontal):
            length = len(line_coords)
            if length == 0: return 0
            
            lookup_length = min(length, 7)
            actual_points = CARPET_POINTS_TABLE[lookup_length] 
            
            # The Non-Linear Patience Curve
            if length == 1: potential_value = 0.5
            elif length == 2: potential_value = 2.5  
            elif length == 3: potential_value = 4.5  
            elif length == 4: potential_value = 6.5  
            else: potential_value = actual_points * 0.8 
                
            my_dist = dist_to_roll_endpoints(my_x, my_y, line_coords, is_horizontal)
            en_dist = dist_to_roll_endpoints(en_x, en_y, line_coords, is_horizontal)
            
            # If a line spans wall-to-wall with no valid entry points, it is dead plaster.
            if my_dist == float('inf') and en_dist == float('inf'):
                return 0.0
            
            if my_dist < en_dist:
                return potential_value + (en_dist - my_dist) * 0.1
            elif en_dist < my_dist:
                # Ensure gravity pull multiplier is always positive even for length 1 (-1 pts)
                gravity_pull = (15 - my_dist) * (max(1, actual_points) * 0.05)
                return -potential_value + gravity_pull
            else:
                return potential_value * 1.5

        # Matrices to store the best horizontal/vertical shares for each square.
        # We separate positive and negative to ensure penalties aren't overridden by trivial positive lines.
        positive_shares = [[0.0 for _ in range(8)] for _ in range(8)]
        negative_shares = [[0.0 for _ in range(8)] for _ in range(8)]

        def add_share(line_coords, is_horizontal):
            val = evaluate_line(line_coords, is_horizontal)
            share = val / len(line_coords)
            for x, y in line_coords:
                if share > 0:
                    positive_shares[y][x] = max(positive_shares[y][x], share)
                else:
                    negative_shares[y][x] = min(negative_shares[y][x], share)

        # --- Evaluate Horizontal Lines ---
        for y in range(8):
            current_line = []
            for x in range(8):
                if board.get_cell((x, y)) == Cell.PRIMED:
                    current_line.append((x, y))
                else:
                    if current_line:
                        add_share(current_line, is_horizontal=True)
                        current_line = []
            if current_line:
                add_share(current_line, is_horizontal=True)
                
        # --- Evaluate Vertical Lines ---
        for x in range(8):
            current_line = []
            for y in range(8):
                if board.get_cell((x, y)) == Cell.PRIMED:
                    current_line.append((x, y))
                else:
                    if current_line:
                        add_share(current_line, is_horizontal=False)
                        current_line = []
            if current_line:
                add_share(current_line, is_horizontal=False)
                
        # Sum the consolidated values to prevent double counting
        prime_bonus = 0
        for y in range(8):
            for x in range(8):
                if board.get_cell((x, y)) == Cell.PRIMED:
                    prime_bonus += positive_shares[y][x] + negative_shares[y][x]
            
        return score + prime_bonus

    def minimax(self, board, depth, alpha, beta, is_maximizing, start_time, time_limit):
        if time.time() - start_time > time_limit:
            raise TimeoutError()

        if depth == 0 or board.is_game_over():
            return self.heuristic(board), None

        # --- Transposition Table Lookup ---
        state_hash = self._hash_board(board, is_maximizing)
        if state_hash in self.tt:
            cached_depth, cached_score, cached_move, flag = self.tt[state_hash]
            if cached_depth >= depth:
                if flag == 'EXACT':
                    return cached_score, cached_move
                elif flag == 'LOWERBOUND':
                    alpha = max(alpha, cached_score)
                elif flag == 'UPPERBOUND':
                    beta = min(beta, cached_score)
                
                if alpha >= beta:
                    return cached_score, cached_move

        orig_alpha = alpha
        orig_beta = beta

        if is_maximizing:
            valid_moves = board.get_valid_moves(enemy=False, exclude_search=True)
            if not valid_moves:
                return self.heuristic(board), None

            def move_priority(m):
                if m.move_type == MoveType.CARPET: 
                    return 100 + (m.roll_length * 2) if m.roll_length >= 4 else 60 + m.roll_length
                if m.move_type == MoveType.PRIME: return 50
                return 0
                
            valid_moves.sort(key=move_priority, reverse=True)

            best_move = valid_moves[0]
            max_eval = float('-inf')
            
            for move in valid_moves:
                next_board = board.forecast_move(move, check_ok=False)
                if next_board is None: continue
                
                eval_score, _ = self.minimax(next_board, depth - 1, alpha, beta, False, start_time, time_limit)
                
                if eval_score > max_eval:
                    max_eval = eval_score
                    best_move = move
                
                alpha = max(alpha, eval_score)
                if beta <= alpha: break
                
            # TT Storage
            flag = 'EXACT'
            if max_eval <= orig_alpha: flag = 'UPPERBOUND'
            elif max_eval >= beta: flag = 'LOWERBOUND'
            self.tt[state_hash] = (depth, max_eval, best_move, flag)
            
            return max_eval, best_move
            
        else:
            board.reverse_perspective()
            valid_moves = board.get_valid_moves(enemy=False, exclude_search=True)
            
            if not valid_moves:
                board.reverse_perspective() 
                return self.heuristic(board), None

            best_move = valid_moves[0]
            min_eval = float('inf')
            
            for move in valid_moves:
                next_board = board.forecast_move(move, check_ok=False)
                if next_board is None: continue
                
                next_board.reverse_perspective()
                
                eval_score, _ = self.minimax(next_board, depth - 1, alpha, beta, True, start_time, time_limit)
                
                if eval_score < min_eval:
                    min_eval = eval_score
                    best_move = move
                    
                beta = min(beta, eval_score)
                if beta <= alpha: break
                
            board.reverse_perspective() 
            
            # TT Storage
            flag = 'EXACT'
            if min_eval <= alpha: flag = 'UPPERBOUND'
            elif min_eval >= orig_beta: flag = 'LOWERBOUND'
            self.tt[state_hash] = (depth, min_eval, best_move, flag)
            
            return min_eval, best_move


    def play(self, board, rat_samples, time_left_func):
        noise, distance = rat_samples
        my_pos = board.player_worker.get_location()

        self.check_rat_resets(board)
        self.hmm.predict()
        self.hmm.update(noise, distance, my_pos, board)

        best_rat_loc, rat_prob = self.hmm.get_best_guess()

        turns_remaining = board.player_worker.turns_left
        time_left = time_left_func()
        
        if turns_remaining > 0:
            time_limit = (time_left / turns_remaining) - self.TIME_BUFFER
        else:
            time_limit = time_left - self.TIME_BUFFER
            
        valid_moves = board.get_valid_moves(enemy=False, exclude_search=True)
        if not valid_moves:
            return Move.search(best_rat_loc)

        # 1. KILLER MOVE OVERRIDE
        carpet_moves = [m for m in valid_moves if m.move_type == MoveType.CARPET]
        if carpet_moves:
            best_carpet = max(carpet_moves, key=lambda m: m.roll_length)
            if best_carpet.roll_length >= 5: 
                return best_carpet

        # 2. ITERATIVE DEEPENING MINIMAX
        start_time = time.time()
        best_tactical_move = random.choice(valid_moves)
        depth = 1
        
        try:
            while True:
                if time.time() - start_time > time_limit * 0.5:
                    break
                    
                score, move = self.minimax(board, depth, float('-inf'), float('inf'), True, start_time, time_limit)
                if move is not None:
                    best_tactical_move = move
                depth += 1
        except TimeoutError:
            pass 

        # 3. TACTICAL VS RAT DECISION
        # Lowered base threshold to compete with George's aggressive EV farming
        base_threshold = 0.45 
        adjusted_threshold = base_threshold + self.weights.get("rat_confidence_threshold", 0.0)
        
        if rat_prob >= adjusted_threshold: 
            return Move.search(best_rat_loc)

        return best_tactical_move

    def commentate(self):
        return "locked in ?"