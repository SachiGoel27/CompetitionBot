import numpy as np
import time
import os
import json
import random
from collections import defaultdict
from game.enums import Cell, Noise, MoveType, Direction, CARPET_POINTS_TABLE
from game.move import Move

NOISE_PROBS = {
    Cell.BLOCKED: (0.5, 0.3, 0.2),
    Cell.SPACE: (0.7, 0.15, 0.15),
    Cell.PRIMED: (0.1, 0.8, 0.1),
    Cell.CARPET: (0.1, 0.1, 0.8),
}

# ==========================================
# ZOBRIST HASHING INITIALIZATION
# ==========================================
# Pre-generate 64-bit random integers for every possible cell state at every position.
# This makes board hashing a hyper-fast bitwise XOR operation instead of string concatenation.
ZOBRIST_TABLE = {}
for x in range(8):
    for y in range(8):
        for cell_type in Cell:
            ZOBRIST_TABLE[(x, y, cell_type)] = random.getrandbits(64)

# We also need hashes for the maximizing turn state
ZOBRIST_TURN_MAX = random.getrandbits(64)

# ==========================================
# THE TRACKER (HMM) - VECTORIZED
# ==========================================
class RatBelief:
    def __init__(self, T_matrix):
        self.T = np.array(T_matrix)
        
        # Pre-compute coordinates to eliminate the 64-iteration for loop later
        self.grid_x = np.arange(64) % 8
        self.grid_y = np.arange(64) // 8
        
        initial_state = np.zeros(64)
        initial_state[0] = 1.0
        T_1000 = np.linalg.matrix_power(self.T, 1000) 
        self.stationary_belief = initial_state @ T_1000
        
        self.belief = np.zeros(64)
        self.reset_and_headstart()

    def reset_and_headstart(self):
        self.belief = self.stationary_belief.copy()

    def predict(self):
        self.belief = self.belief @ self.T 

    def update(self, noise, reported_distance, my_pos, board):
        my_x, my_y = my_pos
        
        # [OPTIMIZATION] Vectorized Noise Probability Lookup
        # We still must fetch cells from the board, but we do it in a fast comprehension
        # then cast to a NumPy array for vectorized multiplication.
        p_noises = np.array([
            NOISE_PROBS[board.get_cell((i % 8, i // 8))][noise.value] 
            for i in range(64)
        ])
        
        # [OPTIMIZATION] Vectorized Distance Calculation
        actual_dists = np.abs(my_x - self.grid_x) + np.abs(my_y - self.grid_y)
        p_dists = np.zeros(64)
        
        # Boolean masking instantly updates the entire 64-cell grid in C-backend
        if reported_distance == 0:
            p_dists[actual_dists == 0] = 0.82
            p_dists[actual_dists == 1] = 0.12
        else:
            p_dists[actual_dists == reported_distance] = 0.70
            p_dists[actual_dists == reported_distance + 1] = 0.12
            p_dists[actual_dists == reported_distance - 1] = 0.12
            p_dists[actual_dists == reported_distance - 2] = 0.06
            
        likelihood = p_noises * p_dists
        self.belief *= likelihood
        self.normalize()

    def normalize(self):
        total_prob = np.sum(self.belief)
        if total_prob > 0:
            self.belief /= total_prob
        else:
            self.belief = np.ones(64) / 64.0

    def get_best_guess(self):
        best_idx = np.argmax(self.belief)
        return (best_idx % 8, best_idx // 8), self.belief[best_idx]


class PlayerAgent:
    def __init__(self, board, transition_matrix, time_left_func):
        self.hmm = RatBelief(transition_matrix)
        self.TIME_BUFFER = 0.8 
        self.tt = {} 
        self.history_table = defaultdict(int) 
        
        # [NEW] Metrics Tracker for the "Ghost Rat" phenomenon
        self.metrics = {
            "total_searches": 0,
            "ghost_rats": 0,
            "max_false_confidence": 0.0
        }
        self.last_search_confidence = 0.0
        
        self.weights = {
            "rat_confidence_threshold": 0.65 
        }
        if 'AGENT_WEIGHTS' in os.environ:
            try: self.weights.update(json.loads(os.environ['AGENT_WEIGHTS']))
            except Exception: pass

    def check_rat_resets(self, board):
        my_guess, my_correct = board.player_search
        if my_guess is not None:
            self.metrics["total_searches"] += 1
            if my_correct:
                self.hmm.reset_and_headstart()
                self.last_search_confidence = 0.0 # Reset on success
            else:
                # [METRICS] If we guessed wrong, check if we were highly confident
                if self.last_search_confidence >= self.weights["rat_confidence_threshold"]:
                    self.metrics["ghost_rats"] += 1
                    self.metrics["max_false_confidence"] = max(self.metrics["max_false_confidence"], self.last_search_confidence)
                
                my_idx = my_guess[1] * 8 + my_guess[0]
                self.hmm.belief[my_idx] = 0.0
                self.hmm.normalize()
                self.last_search_confidence = 0.0 # Reset after recording
                
        op_guess, op_correct = board.opponent_search
        if op_guess is not None:
            if op_correct:
                self.hmm.reset_and_headstart()
            else:
                op_idx = op_guess[1] * 8 + op_guess[0]
                self.hmm.belief[op_idx] = 0.0
                self.hmm.normalize()

    def _hash_board(self, board, is_maximizing):
        # [OPTIMIZATION] Zobrist Hashing implementation
        # XORing integers is vastly faster than string allocation and concatenation
        h = 0
        for x in range(8):
            for y in range(8):
                cell = board.get_cell((x, y))
                h ^= ZOBRIST_TABLE[(x, y, cell)]
                
        # We incorporate player positions and points directly into the hash
        # We multiply by primes to avoid symmetric collisions
        p_x, p_y = board.player_worker.get_location()
        e_x, e_y = board.opponent_worker.get_location()
        
        h ^= (p_x * 73856093 ^ p_y * 19349663)
        h ^= (e_x * 83492791 ^ e_y * 39916801)
        h ^= (board.player_worker.get_points() * 104729)
        h ^= (board.opponent_worker.get_points() * 104723)
        
        if is_maximizing:
            h ^= ZOBRIST_TURN_MAX
            
        return h

    def heuristic(self, board):
        score = board.player_worker.get_points() - board.opponent_worker.get_points()
        my_x, my_y = board.player_worker.get_location()
        en_x, en_y = board.opponent_worker.get_location()
        
        def quick_dist(x1, y1, x2, y2):
            return abs(x1 - x2) + abs(y1 - y2)

        # [OPTIMIZATION] Zero-Allocation Line Evaluation
        # We no longer pass arrays/lists. We pass raw coordinates and lengths.
        def evaluate_line(start_x, start_y, end_x, end_y, length, is_horizontal):
            if length == 0: return 0
            
            actual_points = CARPET_POINTS_TABLE[min(length, 7)] 
            if length == 1: potential_value = 0.5
            elif length == 2: potential_value = 2.5  
            elif length == 3: potential_value = 4.5  
            elif length == 4: potential_value = 6.5  
            else: potential_value = actual_points * 0.8 
            
            my_dist, en_dist = float('inf'), float('inf')
            
            if is_horizontal:
                if start_x > 0 and board.get_cell((start_x - 1, start_y)) != Cell.BLOCKED:
                    my_dist = min(my_dist, quick_dist(my_x, my_y, start_x - 1, start_y))
                    en_dist = min(en_dist, quick_dist(en_x, en_y, start_x - 1, start_y))
                if end_x < 7 and board.get_cell((end_x + 1, end_y)) != Cell.BLOCKED:
                    my_dist = min(my_dist, quick_dist(my_x, my_y, end_x + 1, end_y))
                    en_dist = min(en_dist, quick_dist(en_x, en_y, end_x + 1, end_y))
            else:
                if start_y > 0 and board.get_cell((start_x, start_y - 1)) != Cell.BLOCKED:
                    my_dist = min(my_dist, quick_dist(my_x, my_y, start_x, start_y - 1))
                    en_dist = min(en_dist, quick_dist(en_x, en_y, start_x, start_y - 1))
                if end_y < 7 and board.get_cell((start_x, end_y + 1)) != Cell.BLOCKED:
                    my_dist = min(my_dist, quick_dist(my_x, my_y, start_x, end_y + 1))
                    en_dist = min(en_dist, quick_dist(en_x, en_y, start_x, end_y + 1))

            if my_dist == float('inf') and en_dist == float('inf'): return 0.0
            if my_dist < en_dist: return potential_value + (en_dist - my_dist) * 0.1
            elif en_dist < my_dist: return -potential_value + ((15 - my_dist) * (max(1, actual_points) * 0.05))
            return potential_value * 1.5

        prime_bonus = 0.0

        # [OPTIMIZATION] Tracker variables instead of lists
        for y in range(8):
            length, s_x, s_y = 0, 0, y
            for x in range(8):
                if board.get_cell((x, y)) == Cell.PRIMED:
                    if length == 0: s_x = x
                    length += 1
                elif length > 0:
                    prime_bonus += evaluate_line(s_x, s_y, x - 1, y, length, True)
                    length = 0
            if length > 0: prime_bonus += evaluate_line(s_x, s_y, 7, y, length, True)
                
        for x in range(8):
            length, s_x, s_y = 0, x, 0
            for y in range(8):
                if board.get_cell((x, y)) == Cell.PRIMED:
                    if length == 0: s_y = y
                    length += 1
                elif length > 0:
                    prime_bonus += evaluate_line(s_x, s_y, x, y - 1, length, False)
                    length = 0
            if length > 0: prime_bonus += evaluate_line(s_x, s_y, x, 7, length, False)
            
        # Optional: Add a micro-bonus for center control to prevent "thrashing"
        center_bias = (abs(3.5 - my_x) + abs(3.5 - my_y)) * -0.01 
        
        return score + (prime_bonus * 0.8) + center_bias

    def minimax(self, board, depth, alpha, beta, is_maximizing, start_time, time_limit):
        if time.time() - start_time > time_limit:
            raise TimeoutError()

        if depth == 0 or board.is_game_over():
            return self.heuristic(board), None

        state_hash = self._hash_board(board, is_maximizing)
        if state_hash in self.tt:
            cached_depth, cached_score, cached_move, flag = self.tt[state_hash]
            if cached_depth >= depth:
                if flag == 'EXACT': return cached_score, cached_move
                elif flag == 'LOWERBOUND': alpha = max(alpha, cached_score)
                elif flag == 'UPPERBOUND': beta = min(beta, cached_score)
                if alpha >= beta: return cached_score, cached_move

        orig_alpha = alpha
        orig_beta = beta

        if is_maximizing:
            valid_moves = board.get_valid_moves(enemy=False, exclude_search=True)
            if not valid_moves: return self.heuristic(board), None

            def move_priority(m):
                base = self.history_table.get(str(m), 0) 
                if m.move_type == MoveType.CARPET: return base + 100 + (m.roll_length * 2)
                if m.move_type == MoveType.PRIME: return base + 50
                return base
                
            valid_moves.sort(key=move_priority, reverse=True)
            best_move = valid_moves[0]
            max_eval = float('-inf')
            
            for move in valid_moves:
                next_board = board.forecast_move(move, check_ok=False)
                if next_board is None: continue
                
                eval_score, _ = self.minimax(next_board, depth - 1, alpha, beta, False, start_time, time_limit)
                
                if eval_score > max_eval:
                    max_eval = eval_score
                    best_move = move
                
                alpha = max(alpha, eval_score)
                if beta <= alpha: 
                    self.history_table[str(move)] += (depth ** 2) 
                    break
                
            flag = 'EXACT'
            if max_eval <= orig_alpha: flag = 'UPPERBOUND'
            elif max_eval >= beta: flag = 'LOWERBOUND'
            self.tt[state_hash] = (depth, max_eval, best_move, flag)
            return max_eval, best_move
            
        else:
            board.reverse_perspective()
            valid_moves = board.get_valid_moves(enemy=False, exclude_search=True)
            if not valid_moves:
                board.reverse_perspective() 
                return self.heuristic(board), None

            valid_moves.sort(key=lambda m: self.history_table.get(str(m), 0), reverse=True)
            best_move = valid_moves[0]
            min_eval = float('inf')
            
            for move in valid_moves:
                next_board = board.forecast_move(move, check_ok=False)
                if next_board is None: continue
                
                next_board.reverse_perspective()
                eval_score, _ = self.minimax(next_board, depth - 1, alpha, beta, True, start_time, time_limit)
                
                if eval_score < min_eval:
                    min_eval = eval_score
                    best_move = move
                    
                beta = min(beta, eval_score)
                if beta <= alpha: 
                    self.history_table[str(move)] += (depth ** 2)
                    break
                
            board.reverse_perspective() 
            flag = 'EXACT'
            if min_eval <= alpha: flag = 'UPPERBOUND'
            elif min_eval >= orig_beta: flag = 'LOWERBOUND'
            self.tt[state_hash] = (depth, min_eval, best_move, flag)
            return min_eval, best_move


    def play(self, board, rat_samples, time_left_func):
        noise, distance = rat_samples
        my_pos = board.player_worker.get_location()

        self.check_rat_resets(board)
        self.hmm.predict()
        self.hmm.update(noise, distance, my_pos, board)

        best_rat_loc, rat_prob = self.hmm.get_best_guess()

        turns_remaining = board.player_worker.turns_left
        time_left = time_left_func()
        
        base_time = (time_left / max(1, turns_remaining)) 
        time_limit = base_time - self.TIME_BUFFER
        if turns_remaining > 20: 
            time_limit = min(base_time * 1.5, time_left * 0.1) - self.TIME_BUFFER
            
        valid_moves = board.get_valid_moves(enemy=False, exclude_search=True)
        if not valid_moves:
            return Move.search(best_rat_loc)

        carpet_moves = [m for m in valid_moves if m.move_type == MoveType.CARPET]
        if carpet_moves:
            best_carpet = max(carpet_moves, key=lambda m: m.roll_length)
            if best_carpet.roll_length >= 5: 
                return best_carpet

        start_time = time.time()
        best_tactical_move = random.choice(valid_moves)
        depth = 1
        
        try:
            while True:
                elapsed = time.time() - start_time
                if elapsed > time_limit * (0.8 if depth < 3 else 0.4):
                    break
                    
                score, move = self.minimax(board, depth, float('-inf'), float('inf'), True, start_time, time_limit)
                if move is not None:
                    best_tactical_move = move
                depth += 1
        except TimeoutError:
            pass 

        adjusted_threshold = self.weights.get("rat_confidence_threshold", 0.65)
        if rat_prob >= adjusted_threshold: 
            # [METRICS] Record our confidence right before we strike
            self.last_search_confidence = rat_prob
            return Move.search(best_rat_loc)

        return best_tactical_move

    def commentate(self):
        # [METRICS] Output the Ghost Rat metrics directly to the game's commentary feed
        searches = self.metrics["total_searches"]
        ghosts = self.metrics["ghost_rats"]
        max_conf = self.metrics["max_false_confidence"]
        
        ghost_rate = (ghosts / searches * 100) if searches > 0 else 0.0
        
        return f"System Online | Searches: {searches} | Ghost Rats: {ghosts} ({ghost_rate:.1f}%) | Max False Conf: {max_conf:.2f}"