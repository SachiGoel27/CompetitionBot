def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def dist_to_center(pos):
    cx, cy = 3.5, 3.5
    return abs(pos[0] - cx) + abs(pos[1] - cy)

def recent_rat_catches(match_data, i, window=5):
    start = max(0, i - window + 1)
    return float(sum(1 for x in match_data["rat_caught"][start:i+1] if x))

def recent_searches(match_data, i, window=5):
    start = max(0, i - window + 1)
    vals = match_data["left_behind"][start:i+1]
    return float(sum(1 for x in vals if x == "search"))

def recent_carpets(match_data, i, window=5):
    start = max(0, i - window + 1)
    total_cells = 0
    long_rolls = 0
    for idx in range(start, i + 1):
        c = match_data["new_carpets"][idx]
        total_cells += len(c)
        if len(c) >= 3:
            long_rolls += 1
    return float(total_cells), float(long_rolls)

def score_swing(match_data, i, window=3):
    start = max(0, i - window)
    a_now = match_data["a_points"][i]
    b_now = match_data["b_points"][i]
    a_prev = match_data["a_points"][start]
    b_prev = match_data["b_points"][start]
    return float((a_now - b_now) - (a_prev - b_prev))

def extract_features_from_match_state(match_data, i):
    a_pos = match_data["a_pos"][i]
    b_pos = match_data["b_pos"][i]

    a_points = float(match_data["a_points"][i])
    b_points = float(match_data["b_points"][i])
    score_diff = a_points - b_points

    a_turns_left = float(match_data["a_turns_left"][i])
    b_turns_left = float(match_data["b_turns_left"][i])

    a_time_left = float(match_data["a_time_left"][i])
    b_time_left = float(match_data["b_time_left"][i])

    rat_caught_now = 1.0 if match_data["rat_caught"][i] else 0.0

    new_carpets = match_data["new_carpets"][i]
    new_carpet_count = float(len(new_carpets))
    long_carpet_now = 1.0 if len(new_carpets) >= 3 else 0.0

    left_behind = match_data["left_behind"][i]
    move_type_map = {
        "plain": 0.0,
        "prime": 1.0,
        "carpet": 2.0,
        "search": 3.0
    }
    move_type_val = move_type_map.get(left_behind, -1.0)

    dist_players = float(manhattan(a_pos, b_pos))
    a_center = float(dist_to_center(a_pos))
    b_center = float(dist_to_center(b_pos))

    rat_catches_recent = recent_rat_catches(match_data, i, window=5)
    searches_recent = recent_searches(match_data, i, window=5)
    recent_carpet_cells, recent_long_rolls = recent_carpets(match_data, i, window=5)
    diff_swing = score_swing(match_data, i, window=3)

    ax, ay = float(a_pos[0]), float(a_pos[1])
    bx, by = float(b_pos[0]), float(b_pos[1])

    features = [
        ax, ay,
        bx, by,
        a_points,
        b_points,
        score_diff,
        a_turns_left,
        b_turns_left,
        a_turns_left - b_turns_left,
        a_time_left,
        b_time_left,
        a_time_left - b_time_left,
        dist_players,
        a_center,
        b_center,
        a_center - b_center,
        rat_caught_now,
        new_carpet_count,
        long_carpet_now,
        move_type_val,
        rat_catches_recent,
        searches_recent,
        recent_carpet_cells,
        recent_long_rolls,
        diff_swing,
    ]

    return features
