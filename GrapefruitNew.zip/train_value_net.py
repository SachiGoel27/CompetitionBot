import json
import joblib
from pathlib import Path

from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from feature_extractor import extract_features_from_match_state

MODEL_OUT = "value_model.pkl"

def load_match(path):
    with open(path, "r") as f:
        return json.load(f)

def get_match_files():
    files = sorted(Path(".").glob("match*.json"))
    if not files:
        raise RuntimeError("No match*.json files found in this folder.")
    return files

def build_dataset():
    X = []
    y = []

    match_files = get_match_files()
    print("Using match files:")
    for f in match_files:
        print(" -", f.name)

    for path in match_files:
        match_data = load_match(path)

        final_a = match_data["a_points"][-1]
        final_b = match_data["b_points"][-1]
        final_diff = float(final_a - final_b)

        num_turns = len(match_data["a_points"])

        for i in range(num_turns):
            feats = extract_features_from_match_state(match_data, i)
            X.append(feats)
            y.append(final_diff)

    if not X:
        raise RuntimeError("No training examples found.")

    print(f"Built dataset with {len(X)} examples.")
    return X, y

def main():
    X, y = build_dataset()

    model = Pipeline([
        ("scaler", StandardScaler()),
        ("mlp", MLPRegressor(
            hidden_layer_sizes=(64, 32),
            activation="relu",
            solver="adam",
            max_iter=1000,
            random_state=42
        ))
    ])

    model.fit(X, y)
    joblib.dump(model, MODEL_OUT)
    print(f"Saved model to {MODEL_OUT}")

if __name__ == "__main__":
    main()
